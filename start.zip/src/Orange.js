import React from 'react';
function Orange() {
	return <h3>Orange</h3>;
}
export default Orange;

import Plate from './Plate';
const Table = () => {
	return (
		<div>
			테이블
      <Plate fav="햄버거" />
      <Plate fav="딸기" />
      <Plate fav="사과" />
		</div>
	);
};
export default Table;

const Plate=(a)=>{
  console.log(a.fav);
  return <div>접시 {a.fav}</div>
}
export default Plate;
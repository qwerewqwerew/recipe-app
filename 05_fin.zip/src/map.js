let cats = ['땅콩', '회색', '얼룩'];

let calls = cats.map((value,) => {

	return value + '밥먹자';


});
//console.log(calls);

let nums = [273, 26, 2489, 216, 53];
let doubles = nums.map(function (value) {
	return value * 2;
});
console.log(doubles);
